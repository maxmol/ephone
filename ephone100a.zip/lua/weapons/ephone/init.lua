include('shared.lua')

AddCSLuaFile('shared.lua')
AddCSLuaFile('cl_init.lua')

function SWEP:PrimaryAttack()

end

function SWEP:SecondaryAttack()

end