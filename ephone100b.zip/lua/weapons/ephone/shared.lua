SWEP.Category = "Other"
SWEP.Spawnable = true
SWEP.AdminSpawnable = true

SWEP.ViewModel = Model('models/elysion/c_phone_model.mdl')
SWEP.WorldModel = Model('models/elysion/w_phone_model.mdl')

SWEP.Primary.Ammo = "none"
SWEP.Secondary.Ammo = "none"

SWEP.IsPicking 	= false
SWEP.PickTime = 15