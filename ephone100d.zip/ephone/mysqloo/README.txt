If you wish to use MySQL,
copy the DLL (corresponding to your server OS) to garrysmod/lua/bin/